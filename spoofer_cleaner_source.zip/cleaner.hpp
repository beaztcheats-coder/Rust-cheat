#pragma once

void CleanerMenu();
