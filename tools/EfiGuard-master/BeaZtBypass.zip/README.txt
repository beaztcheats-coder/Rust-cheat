BeaZt Bypass - Setup Guide
==========================

WHAT THIS DOES:
- Disables PatchGuard at boot time
- Temporarily disables DSE so your cheat loader can load unsigned driver
- Re-enables DSE before Rust launches so EAC cannot detect it
- Works on Windows 10/11 x64 (24H2, 25H2, all builds)

==================
STEP 1: USB DRIVE
==================
1. Format USB as FAT32 (use Rufus for drives >32GB)
2. Extract ALL files from zip to ROOT of USB (no subfolders!)

==================
STEP 2: BIOS SETTINGS
==================
1. Disable Secure Boot in BIOS
2. Disable Memory Integrity: Windows Security -> Device Security -> Core isolation -> OFF
3. Restart

==================
STEP 3: BOOT FROM USB
==================
1. Press boot menu key (F8/F11/F12)
2. Select USB drive
3. You MUST see "BeaZt Bypass" text on screen
4. Windows boots automatically

==================
STEP 4: RUN CHEAT LOADER
==================
1. Double-click "Start BeaZt.bat" on USB (auto-elevates to admin)
2. Script disables DSE
3. Script pauses - NOW run your cheat loader:
   - Enter serial key
   - Let it load driver and inject DLL
   - Wait until fully done
4. Press any key
5. Script re-enables DSE
6. Launch Rust when prompted

DONE. That's the whole flow:
  Boot USB -> Start BeaZt.bat -> Run cheat loader -> Press key -> Launch Rust

==================
WHY EAC PASSES
==================
- DSE disabled only while your cheat loader runs (seconds)
- DSE re-enabled BEFORE Rust launches
- EAC checks DSE at launch -> sees ENABLED -> passes
- Driver stays in memory (DSE blocks LOADING, not RUNNING)

==================
TROUBLESHOOTING
==================
"No BeaZt logo during boot"
  -> Secure Boot still on. Disable in BIOS.
  -> USB not FAT32. Use Rufus.
  -> Files in subfolder. Copy to root of USB.

"VBS is enabled" / "0xC000000BB"
  -> Disable Memory Integrity in Windows Security, reboot with USB.

"0xC0000225"
  -> Make sure you have the latest zip (EfiDSEFix.exe should be 22,016 bytes).

"Error 30007" launching Rust
  -> DSE still disabled. Use Start BeaZt.bat (re-enables DSE after loader).

"Failed to open device handle"
  -> Run Start BeaZt.bat FIRST (disables DSE), THEN run your cheat loader.
