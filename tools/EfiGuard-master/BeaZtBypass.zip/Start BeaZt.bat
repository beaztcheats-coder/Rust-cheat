@echo off
:: BeaZt Bypass - All-in-One Loader
:: Disables DSE so your cheat loader can load unsigned driver,
:: then re-enables DSE before Rust launches so EAC doesn't detect it.

:: Check for admin rights
net session >nul 2>&1
if %errorlevel% neq 0 (
    powershell -Command "Start-Process '%~f0' -Verb RunAs"
    exit /b
)

:: Check if EfiDSEFix.exe exists
if not exist "%~dp0EfiDSEFix.exe" (
    echo ERROR: EfiDSEFix.exe not found in same folder!
    pause
    exit /b 1
)

echo.
echo ============================================
echo   BeaZt Bypass - All-in-One Loader
echo ============================================
echo.

:: ============================================
:: STEP 1: Disable DSE
:: ============================================
echo [1/4] Disabling DSE (Driver Signature Enforcement)...
"%~dp0EfiDSEFix.exe" -d
if %errorlevel% neq 0 (
    echo.
    echo ============================================
    echo  FAILED to disable DSE!
    echo.
    echo  Make sure you booted from the BeaZt Bypass USB.
    echo  If VBS error: disable Memory Integrity in
    echo  Windows Security first, then reboot with USB.
    echo ============================================
    pause
    exit /b 1
)
echo  DSE is now DISABLED.
echo.

:: ============================================
:: STEP 2: User runs their cheat loader
:: ============================================
echo [2/4] RUN YOUR CHEAT LOADER NOW
echo.
echo  - Open your cheat loader (the one with serial key)
echo  - Enter your serial key
echo  - Let it load the driver and inject the DLL
echo  - Wait until your cheat loader is fully done
echo.
echo  DSE is disabled right now so your unsigned
echo  driver can load. Take your time.
echo.
echo  Press any key ONLY AFTER your cheat loader
echo  has finished completely...
echo ============================================
pause >nul
echo.

:: ============================================
:: STEP 3: Re-enable DSE
:: ============================================
echo [3/4] Re-enabling DSE (so EAC cannot detect it)...
"%~dp0EfiDSEFix.exe" -e
if %errorlevel% neq 0 (
    echo.
    echo  WARNING: Failed to re-enable DSE!
    echo  Try running: EfiDSEFix.exe -e manually.
    echo  Do NOT launch Rust until DSE is re-enabled.
    pause
    exit /b 1
)
echo  DSE re-enabled successfully.
echo.

:: ============================================
:: STEP 4: Verify and launch
:: ============================================
echo [4/4] Verifying DSE status...
"%~dp0EfiDSEFix.exe" -r
echo.
echo ============================================
echo  ALL DONE!
echo.
echo  - PatchGuard: DISABLED (by BeaZt Bypass at boot)
echo  - Cheat driver: LOADED (by your cheat loader)
echo  - Cheat DLL: INJECTED (by your cheat loader)
echo  - DSE: RE-ENABLED (EAC will not detect)
echo.
echo  You can now launch Rust through Steam.
echo  EAC will pass - DSE is enabled and your
echo  driver is already loaded in memory.
echo ============================================
echo.

set /p "LAUNCH=Launch Rust now? (Y/N): "
if /i "%LAUNCH%"=="Y" (
    echo Launching Rust...
    start steam://run/252490
)

pause
